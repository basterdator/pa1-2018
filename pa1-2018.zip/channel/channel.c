#define _WINSOCK_DEPRECATED_NO_WARNINGS

#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS
#endif

#include <stdio.h>
#include <string.h>
#include <winsock2.h>
#pragma comment(lib, "ws2_32.lib")

#define SERVER_ADDRESS_STR "127.0.0.1"
#define IN_PORT 2345
#define MAX_CLIENTS 1
#define NETWORK_ERROR -1
#define NETWORK_OK     0
#define MSG_SIZE 64

typedef enum { TRNS_FAILED, TRNS_DISCONNECTED, TRNS_SUCCEEDED } TransferResult_t;

typedef struct {  // block of 8X8 bits
	unsigned char wrd[8];
}blk;

typedef struct { // data structure of 1 bit, can hold 0 or 1
	unsigned short value : 1;
}bit;

SOCKET udp_s;
unsigned long Address;
struct sockaddr_in my_addr;
struct sockaddr_in sender_addr;
struct sockaddr_in reciever_addr;

HANDLE hThread[2];

static DWORD RecvFromSender(LPVOID lpParam);

void ReportError(int errorCode, const char *whichFunc);

int main(int argc, char* argv[])
{
	int nret;
	// initialize windows networking
	WSADATA wsaData;
	nret = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (nret != NO_ERROR)
		printf("Error at WSAStartup()\n");

	// create the socket that will listen for incoming TCP connections
	udp_s = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if (udp_s == INVALID_SOCKET)
	{
		nret = WSAGetLastError();
		ReportError(nret, "socket()");
		WSACleanup();
		return NETWORK_ERROR;
	}

	Address = inet_addr(SERVER_ADDRESS_STR);
	if (Address == INADDR_NONE)
	{
		nret = WSAGetLastError();
		ReportError(nret, "address convertion");
		WSACleanup();
		return NETWORK_ERROR;
	}

	my_addr.sin_family = AF_INET;
	my_addr.sin_addr.s_addr = Address;
	my_addr.sin_port = htons(atoi(argv[1]));
	nret = bind(udp_s, (SOCKADDR*)&my_addr, sizeof(my_addr));



	hThread[0] = CreateThread(
		NULL,
		0,
		(LPTHREAD_START_ROUTINE)RecvFromSender, // A thread which recieves data on the socket and proccesses it
		NULL,
		0,
		NULL
	);

}
static DWORD RecvFromSender(LPVOID lpParam)
{

}
void ReportError(int errorCode, const char *whichFunc)
{
	char errorMsg[92];					// Declare a buffer to hold the generated error message
	ZeroMemory(errorMsg, 92);			// Automatically NULL-terminate the string The following line copies the phrase, whichFunc string, and integer errorCode into the buffer
	sprintf(errorMsg, "Call to %s returned error %d!", (char *)whichFunc, errorCode);
	MessageBox(NULL, errorMsg, "socketIndication", MB_OK);
}
